# grattanReporter 0.23.1
* Use a more precise version of `inputs_of` to handle custom inputs like `\includenextfigure`

# grattanReporter 0.23.0

* Added a `NEWS.md` file to track changes to the package.
* `validate_bibliography()` now writes MD5 sum to travis/grattanReporter/md5 for speedier subsequent validation
* Added NEM capacity markets paper for validation


