#' List of wrongly spelled words
#' @format A regex of patterns to raise as spelling errors.

"wrongly_spelled_words"
