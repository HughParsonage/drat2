#' List of correctly spelled words
#' @format A character vector of words as perl-regex patterns to skip during the spell check.

"correctly_spelled_words"
