[![Travis-CI Build Status](https://travis-ci.org/HughParsonage/hutils.svg?branch=master)](https://travis-ci.org/HughParsonage/hutils)
[![codecov.io](https://codecov.io/github/HughParsonage/hutils/coverage.svg?branch=master)](https://codecov.io/github/HughParsonage/hutils?branch=master)
[![AppVeyor Build Status](https://ci.appveyor.com/HughParsonage/hutils)](https://ci.appveyor.com/api/projects/status/github//HughParsonage/hutils/?branch=master&svg=true)


# hutils
Miscellaneous R functions and aliases
