#' Fictional 2015-16 sample file
#' @description Since the 2015-16 sample file is not public, this file has been used to test basic compatibility with it. It has the same number of rows, but that's about it. There is no guarantee that file is representative; indeed the values may be nonsensical. Contact the ATO to obtain a sample file that is useable research purposes.
#'

"sample_file_1516_synth"
